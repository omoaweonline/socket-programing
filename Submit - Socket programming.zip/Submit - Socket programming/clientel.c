#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 4096

int main(int argc, char **argv) {

    char *tk, *ip, *port, *path;
    
    tk = strtok(argv[1], ":");
    ip = tk;
    
    tk = strtok(NULL, "/");
    port = tk;
    
    tk = strtok(NULL, "");
    path = tk; 

    // The server IP address and port number to connect to
    char *server_ip = ip;
    char *server_port = atoi(port);
    // The path of the file to download from the server
    char *file_path = path;
    // Create a socket
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd < 0) {
        perror("Error creating socket");
        return 1;
    }
    // Connect to the server
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        perror("Invalid server IP address");
        return 1;
    }
    if (connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Error connecting to server");
        return 1;
    }
    // Send the file path to the server to request the file
    if (send(socket_fd, file_path, strlen(file_path), 0) < 0) {
        perror("Error sending file path");
        return 1;
    }
    // Open a file to write the downloaded data to
    FILE *file = fopen("downloaded_file", "wb");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }
    // Receive data from the server and write it to the file
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;
    while ((bytes_read = recv(socket_fd, buffer, BUFFER_SIZE, 0)) > 0) {
    	printf("downloading...");
        if (fwrite(buffer, sizeof(char), bytes_read, file) != bytes_read) {
            perror("Error writing to file");
            return 1;
        }
    }
    if (bytes_read < 0) {
        perror("Error receiving data");
        return 1;
    }
    // Close the file and socket
    fclose(file);
    close(socket_fd);
    printf("File downloaded successfully\n");
    return 0;
}

