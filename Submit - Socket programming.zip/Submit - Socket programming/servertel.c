#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 1024

int main(int argc, char **argv) {

    pid_t a_child_process;

    // The port number to listen on for client connections
    int server_port = atoi(argv[1]);
  
    // Create a socket
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd < 0) {
        perror("Error creating socket");
        return 1;
    }
    // Bind the socket to the server address and port
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(server_port);
    if (bind(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Error binding socket");
        return 1;
    }
    // Listen for client connections
    if (listen(socket_fd, 1) < 0) {
        perror("Error listening for connections");
        return 1;
    }
    printf("Server listening on port %d\n", server_port);
    while (1) {
        // Accept a new client connection
        struct sockaddr_in client_addr;
        socklen_t client_addr_len = sizeof(client_addr);
        int client_fd = accept(socket_fd, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_fd < 0) {
            perror("Error accepting client connection");
            continue;
        }
        printf("Client connected: %s\n", inet_ntoa(client_addr.sin_addr));
        
        if((a_child_process = fork()) == 0)
        {
        	close(socket_fd);
        	
        	// Receive the file path from the client
		char file_path_buffer[BUFFER_SIZE];
		ssize_t bytes_received = recv(client_fd, file_path_buffer, BUFFER_SIZE, 0);
		if (bytes_received < 0) {
		    perror("HTTP/1.1 404 Not Found");
		    close(client_fd);
		    continue;
		}
		file_path_buffer[bytes_received] = '\0';
		// Open the requested file and send its contents to the client
		FILE *file = fopen(file_path_buffer, "rb");
		if (file == NULL) {
		    perror("Error opening file");
		    close(client_fd);
		    continue;
		}
		char buffer[BUFFER_SIZE];
		ssize_t bytes_read;
		while ((bytes_read = fread(buffer, sizeof(char), BUFFER_SIZE, file)) > 0) {
		    if (send(client_fd, buffer, bytes_read, 0) != bytes_read) {
		        perror("Error sending data to client");
		        fclose(file);
		        close(client_fd);
		        continue;
		    }
		}
		if (ferror(file)) {
		    perror("HTTP/1.1 400 Bad Request \n Error reading file");
		    fclose(file);
		    close(client_fd);
		    continue;
		}
		// Close the file and client socket
		fclose(file);
		close(client_fd);
		printf("HTTP/1.1 200 OK \n File sent successfully\n");
        
        }else{
        	close(client_fd);
        }
        
    }
    return 0;
}

